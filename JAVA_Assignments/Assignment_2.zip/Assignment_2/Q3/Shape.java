package Q3;
public abstract class Shape {
    void method(){
        System.out.println("abstract class method");
    }
   abstract void type(String shape);
}
