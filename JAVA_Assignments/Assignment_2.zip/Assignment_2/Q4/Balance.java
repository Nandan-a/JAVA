

public interface Balance{
    int basic=100;
    int HRA=50;
    public void calculateSalary();
}


