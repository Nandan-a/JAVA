// package Q4;

class Salary implements Balance{
    public void calculateSalary(){
        int cal = basic + HRA;
        System.out.println(cal);
    }
}
