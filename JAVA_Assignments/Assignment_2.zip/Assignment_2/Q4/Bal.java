public class Bal {
    public static void main(String[] args) {
        Salary s1 = new Salary();
        s1.calculateSalary();
    }
}
